import React, { useState, useEffect } from "react";
import { useSearchParams, useNavigate } from "react-router-dom";
import { format, formatDistanceToNow, isPast, isToday } from "date-fns";
import { api } from "../utils/api";
import AddTodoModal from "../components/AddTodoModal";
import "./TodoDetailPage.css";

const PRIORITY_CONFIG = {
  high: { color: "#ef4444", label: "High Priority", bg: "rgba(239,68,68,0.1)" },
  medium: { color: "#f59e0b", label: "Medium Priority", bg: "rgba(245,158,11,0.1)" },
  low: { color: "#22c55e", label: "Low Priority", bg: "rgba(34,197,94,0.1)" },
};

export default function TodoDetailPage() {
  const [params] = useSearchParams();
  const navigate = useNavigate();
  const id = params.get("id");

  const [todo, setTodo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showEdit, setShowEdit] = useState(false);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!id) { navigate("/404"); return; }
    fetchTodo();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  const fetchTodo = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await api.getTodo(id);
      setTodo(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  const handleToggleComplete = async () => {
    setSaving(true);
    try {
      const updated = await api.patchTodo(id, { completed: !todo.completed });
      setTodo(updated);
    } catch (e) {
      setError(e.message);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleSubtask = async (subtaskId) => {
    const updated = todo.subtasks.map((s) =>
      s.id === subtaskId ? { ...s, completed: !s.completed } : s
    );
    try {
      const result = await api.patchTodo(id, { subtasks: updated });
      setTodo(result);
    } catch (e) {
      setError(e.message);
    }
  };

  const handleDelete = async () => {
    if (!window.confirm("Delete this task permanently?")) return;
    try {
      await api.deleteTodo(id);
      navigate("/");
    } catch (e) {
      setError(e.message);
    }
  };

  const handleSave = async (data) => {
    try {
      const updated = await api.updateTodo(id, data);
      setTodo(updated);
      setShowEdit(false);
    } catch (e) {
      setError(e.message);
    }
  };

  if (loading) {
    return (
      <div className="detail-page">
        <div className="loading-state">
          <div className="spinner" />
          <p>Loading task…</p>
        </div>
      </div>
    );
  }

  if (error && !todo) {
    return (
      <div className="detail-page">
        <div className="error-center">
          <div className="error-icon">⚠</div>
          <h2>Something went wrong</h2>
          <p>{error}</p>
          <button className="btn-back" onClick={() => navigate("/")}>← Back to tasks</button>
        </div>
      </div>
    );
  }

  const pc = PRIORITY_CONFIG[todo.priority];
  const isOverdue = todo.dueDate && !todo.completed && isPast(new Date(todo.dueDate)) && !isToday(new Date(todo.dueDate));
  const isDueToday = todo.dueDate && !todo.completed && isToday(new Date(todo.dueDate));
  const completedSubtasks = todo.subtasks?.filter((s) => s.completed).length || 0;
  const totalSubtasks = todo.subtasks?.length || 0;
  const subtaskProgress = totalSubtasks > 0 ? (completedSubtasks / totalSubtasks) * 100 : 0;

  return (
    <div className="detail-page">
      <div className="detail-nav">
        <button className="btn-back" onClick={() => navigate("/")}>
          ← All tasks
        </button>
        <div className="nav-actions">
          <button className="btn-edit" onClick={() => setShowEdit(true)}>Edit task</button>
          <button className="btn-delete" onClick={handleDelete}>Delete</button>
        </div>
      </div>

      <div className="detail-card">
        {/* Priority stripe */}
        <div className="priority-stripe" style={{ background: pc.color }} />

        <div className="detail-content">
          {/* Header */}
          <div className="detail-header">
            <button
              className={`big-checkbox ${todo.completed ? "checked" : ""}`}
              onClick={handleToggleComplete}
              disabled={saving}
            >
              {todo.completed && "✓"}
            </button>
            <div className="detail-title-group">
              <h1 className={`detail-title ${todo.completed ? "crossed" : ""}`}>
                {todo.title}
              </h1>
              <span
                className="priority-pill"
                style={{ color: pc.color, background: pc.bg }}
              >
                {pc.label}
              </span>
            </div>
          </div>

          {error && (
            <div className="error-inline">⚠ {error}</div>
          )}

          {/* Status badge */}
          <div className="status-row">
            <span className={`status-badge ${todo.completed ? "status-done" : "status-active"}`}>
              {todo.completed ? "✓ Completed" : "⏳ Active"}
            </span>
            {todo.completed && todo.completedAt && (
              <span className="meta-text">
                Completed {formatDistanceToNow(new Date(todo.completedAt), { addSuffix: true })}
              </span>
            )}
          </div>

          {/* Description */}
          {todo.description && (
            <div className="section">
              <h3 className="section-label">Description</h3>
              <p className="detail-description">{todo.description}</p>
            </div>
          )}

          {/* Metadata grid */}
          <div className="meta-grid">
            <div className="meta-item">
              <span className="meta-label">Created</span>
              <span className="meta-value">
                {format(new Date(todo.createdAt), "MMM d, yyyy 'at' h:mm a")}
              </span>
            </div>
            <div className="meta-item">
              <span className="meta-label">Last updated</span>
              <span className="meta-value">
                {formatDistanceToNow(new Date(todo.updatedAt), { addSuffix: true })}
              </span>
            </div>
            {todo.dueDate && (
              <div className={`meta-item ${isOverdue ? "meta-overdue" : isDueToday ? "meta-today" : ""}`}>
                <span className="meta-label">Due date</span>
                <span className="meta-value">
                  {format(new Date(todo.dueDate), "EEEE, MMMM d, yyyy")}
                  {isOverdue && " · Overdue"}
                  {isDueToday && " · Today"}
                </span>
              </div>
            )}
          </div>

          {/* Tags */}
          {todo.tags?.length > 0 && (
            <div className="section">
              <h3 className="section-label">Tags</h3>
              <div className="detail-tags">
                {todo.tags.map((t) => (
                  <span key={t} className="detail-tag">#{t}</span>
                ))}
              </div>
            </div>
          )}

          {/* Subtasks */}
          {totalSubtasks > 0 && (
            <div className="section">
              <div className="subtask-header">
                <h3 className="section-label">Subtasks</h3>
                <span className="subtask-count">{completedSubtasks} / {totalSubtasks}</span>
              </div>
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${subtaskProgress}%` }} />
              </div>
              <ul className="subtask-detail-list">
                {todo.subtasks.map((s) => (
                  <li key={s.id} className={s.completed ? "sub-complete" : ""}>
                    <button
                      className={`sub-check-btn ${s.completed ? "checked" : ""}`}
                      onClick={() => handleToggleSubtask(s.id)}
                    >
                      {s.completed ? "✓" : ""}
                    </button>
                    <span>{s.title}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Complete button */}
          <button
            className={`btn-complete ${todo.completed ? "btn-undo" : ""}`}
            onClick={handleToggleComplete}
            disabled={saving}
          >
            {todo.completed ? "↩ Mark as active" : "✓ Mark as complete"}
          </button>
        </div>
      </div>

      {showEdit && (
        <AddTodoModal
          initial={todo}
          onSave={handleSave}
          onClose={() => setShowEdit(false)}
        />
      )}
    </div>
  );
}
