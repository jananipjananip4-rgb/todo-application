import React from "react";
import { useNavigate } from "react-router-dom";

export default function NotFoundPage() {
  const navigate = useNavigate();
  return (
    <div style={{
      minHeight: "100vh", display: "flex", flexDirection: "column",
      alignItems: "center", justifyContent: "center",
      background: "var(--bg)", color: "var(--text)", textAlign: "center", padding: "2rem"
    }}>
      <div style={{ fontSize: "4rem", marginBottom: "1rem" }}>404</div>
      <h1 style={{ fontSize: "1.5rem", marginBottom: "0.5rem" }}>Page not found</h1>
      <p style={{ color: "var(--text-muted)", marginBottom: "2rem" }}>
        The page you're looking for doesn't exist.
      </p>
      <button
        onClick={() => navigate("/")}
        style={{
          background: "var(--accent)", color: "#fff", border: "none",
          borderRadius: "8px", padding: "0.7rem 1.5rem", fontSize: "1rem",
          cursor: "pointer"
        }}
      >
        Back to tasks
      </button>
    </div>
  );
}
