import React, { useState, useEffect, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import { api } from "../utils/api";
import TodoItem from "../components/TodoItem";
import AddTodoModal from "../components/AddTodoModal";
import "./TodoListPage.css";

const FILTERS = ["all", "active", "completed"];
const PRIORITIES = ["all", "low", "medium", "high"];
const SORT_OPTIONS = [
  { value: "", label: "Newest first" },
  { value: "dueDate", label: "Due date" },
  { value: "priority", label: "Priority" },
  { value: "title", label: "Title (A–Z)" },
];

export default function TodoListPage() {
  const navigate = useNavigate();
  const [todos, setTodos] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [editTodo, setEditTodo] = useState(null);

  // Filters & search state
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [priorityFilter, setPriorityFilter] = useState("all");
  const [sortBy, setSortBy] = useState("");
  const [sortOrder] = useState("desc");

  const fetchTodos = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const params = {
        search: search || undefined,
        status: statusFilter === "all" ? undefined : statusFilter,
        priority: priorityFilter === "all" ? undefined : priorityFilter,
        sortBy: sortBy || undefined,
        sortOrder,
      };
      const data = await api.getTodos(params);
      setTodos(data);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [search, statusFilter, priorityFilter, sortBy, sortOrder]);

  useEffect(() => {
    fetchTodos();
  }, [fetchTodos]);

  const handleToggle = async (id, completed) => {
    try {
      const updated = await api.patchTodo(id, { completed });
      setTodos((prev) => prev.map((t) => (t.id === id ? updated : t)));
    } catch (e) {
      setError(e.message);
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm("Delete this todo?")) return;
    try {
      await api.deleteTodo(id);
      setTodos((prev) => prev.filter((t) => t.id !== id));
    } catch (e) {
      setError(e.message);
    }
  };

  const handleClearCompleted = async () => {
    if (!window.confirm("Delete all completed todos?")) return;
    try {
      await api.clearCompleted();
      fetchTodos();
    } catch (e) {
      setError(e.message);
    }
  };

  const handleSave = async (todoData) => {
    try {
      if (editTodo) {
        await api.updateTodo(editTodo.id, todoData);
      } else {
        await api.createTodo(todoData);
      }
      setShowModal(false);
      setEditTodo(null);
      fetchTodos();
    } catch (e) {
      setError(e.message);
    }
  };

  const openEdit = (todo) => {
    setEditTodo(todo);
    setShowModal(true);
  };

  const totalActive = todos.filter ? 0 : 0;
  const activeTodosCount = todos.filter((t) => !t.completed).length;
  const completedCount = todos.filter((t) => t.completed).length;

  return (
    <div className="page">
      <header className="header">
        <div className="header-inner">
          <div className="logo">
            <span className="logo-icon">✓</span>
            <h1>TaskFlow</h1>
          </div>
          <p className="tagline">Get things done, one task at a time</p>
        </div>
      </header>

      <main className="main">
        {/* Stats bar */}
        <div className="stats-bar">
          <div className="stat">
            <span className="stat-num">{todos.length}</span>
            <span className="stat-label">Total</span>
          </div>
          <div className="stat">
            <span className="stat-num stat-active">{activeTodosCount}</span>
            <span className="stat-label">Active</span>
          </div>
          <div className="stat">
            <span className="stat-num stat-done">{completedCount}</span>
            <span className="stat-label">Done</span>
          </div>
          <button className="btn-add" onClick={() => { setEditTodo(null); setShowModal(true); }}>
            + New Task
          </button>
        </div>

        {/* Search & Filters */}
        <div className="controls">
          <input
            className="search-input"
            type="text"
            placeholder="Search tasks…"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
          <div className="filter-group">
            <div className="filter-tabs">
              {FILTERS.map((f) => (
                <button
                  key={f}
                  className={`filter-tab ${statusFilter === f ? "active" : ""}`}
                  onClick={() => setStatusFilter(f)}
                >
                  {f.charAt(0).toUpperCase() + f.slice(1)}
                </button>
              ))}
            </div>
            <div className="filter-tabs priority-tabs">
              {PRIORITIES.map((p) => (
                <button
                  key={p}
                  className={`filter-tab priority-${p} ${priorityFilter === p ? "active" : ""}`}
                  onClick={() => setPriorityFilter(p)}
                >
                  {p.charAt(0).toUpperCase() + p.slice(1)}
                </button>
              ))}
            </div>
            <select
              className="sort-select"
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
            >
              {SORT_OPTIONS.map((o) => (
                <option key={o.value} value={o.value}>{o.label}</option>
              ))}
            </select>
          </div>
        </div>

        {/* Error */}
        {error && (
          <div className="error-banner">
            ⚠ {error}
            <button onClick={() => setError(null)}>✕</button>
          </div>
        )}

        {/* Todo list */}
        {loading ? (
          <div className="loading-state">
            <div className="spinner" />
            <p>Loading tasks…</p>
          </div>
        ) : todos.length === 0 ? (
          <div className="empty-state">
            <div className="empty-icon">📋</div>
            <h3>No tasks here</h3>
            <p>
              {search || statusFilter !== "all" || priorityFilter !== "all"
                ? "Try adjusting your filters or search."
                : "Add your first task to get started."}
            </p>
            {!(search || statusFilter !== "all" || priorityFilter !== "all") && (
              <button className="btn-add" onClick={() => setShowModal(true)}>
                + Add your first task
              </button>
            )}
          </div>
        ) : (
          <ul className="todo-list">
            {todos.map((todo) => (
              <TodoItem
                key={todo.id}
                todo={todo}
                onToggle={handleToggle}
                onDelete={handleDelete}
                onEdit={openEdit}
                onViewDetail={() => navigate(`/todo?id=${todo.id}`)}
              />
            ))}
          </ul>
        )}

        {/* Footer actions */}
        {completedCount > 0 && (
          <div className="list-footer">
            <span>{activeTodosCount} task{activeTodosCount !== 1 ? "s" : ""} remaining</span>
            <button className="btn-clear" onClick={handleClearCompleted}>
              Clear {completedCount} completed
            </button>
          </div>
        )}
      </main>

      {showModal && (
        <AddTodoModal
          initial={editTodo}
          onSave={handleSave}
          onClose={() => { setShowModal(false); setEditTodo(null); }}
        />
      )}
    </div>
  );
}
