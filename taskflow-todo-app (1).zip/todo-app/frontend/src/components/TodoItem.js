import React from "react";
import { format, isPast, isToday } from "date-fns";
import "./TodoItem.css";

const PRIORITY_LABEL = { high: "High", medium: "Med", low: "Low" };

export default function TodoItem({ todo, onToggle, onDelete, onEdit, onViewDetail }) {
  const isOverdue = todo.dueDate && !todo.completed && isPast(new Date(todo.dueDate)) && !isToday(new Date(todo.dueDate));
  const isDueToday = todo.dueDate && !todo.completed && isToday(new Date(todo.dueDate));

  const completedSubtasks = todo.subtasks?.filter((s) => s.completed).length || 0;
  const totalSubtasks = todo.subtasks?.length || 0;

  return (
    <li className={`todo-item ${todo.completed ? "completed" : ""} priority-${todo.priority}`}>
      <button
        className="checkbox"
        onClick={() => onToggle(todo.id, !todo.completed)}
        aria-label={todo.completed ? "Mark incomplete" : "Mark complete"}
      >
        {todo.completed && <span className="check-icon">✓</span>}
      </button>

      <div className="todo-body" onClick={onViewDetail} title="View details">
        <div className="todo-title">{todo.title}</div>

        {todo.description && (
          <div className="todo-description">{todo.description}</div>
        )}

        <div className="todo-meta">
          <span className={`priority-badge priority-${todo.priority}`}>
            {PRIORITY_LABEL[todo.priority]}
          </span>

          {todo.dueDate && (
            <span className={`due-badge ${isOverdue ? "overdue" : isDueToday ? "today" : ""}`}>
              📅 {isOverdue ? "Overdue · " : isDueToday ? "Today · " : ""}
              {format(new Date(todo.dueDate), "MMM d")}
            </span>
          )}

          {totalSubtasks > 0 && (
            <span className="subtask-badge">
              ☑ {completedSubtasks}/{totalSubtasks}
            </span>
          )}

          {todo.tags?.map((tag) => (
            <span key={tag} className="tag-badge">#{tag}</span>
          ))}
        </div>
      </div>

      <div className="todo-actions">
        <button
          className="action-btn edit-btn"
          onClick={(e) => { e.stopPropagation(); onEdit(todo); }}
          title="Edit"
        >
          ✏
        </button>
        <button
          className="action-btn delete-btn"
          onClick={(e) => { e.stopPropagation(); onDelete(todo.id); }}
          title="Delete"
        >
          🗑
        </button>
      </div>
    </li>
  );
}
