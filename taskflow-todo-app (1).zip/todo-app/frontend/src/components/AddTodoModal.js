import React, { useState, useEffect } from "react";
import "./AddTodoModal.css";

export default function AddTodoModal({ initial, onSave, onClose }) {
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("medium");
  const [dueDate, setDueDate] = useState("");
  const [tagInput, setTagInput] = useState("");
  const [tags, setTags] = useState([]);
  const [subtaskInput, setSubtaskInput] = useState("");
  const [subtasks, setSubtasks] = useState([]);
  const [error, setError] = useState("");

  useEffect(() => {
    if (initial) {
      setTitle(initial.title || "");
      setDescription(initial.description || "");
      setPriority(initial.priority || "medium");
      setDueDate(initial.dueDate ? initial.dueDate.split("T")[0] : "");
      setTags(initial.tags || []);
      setSubtasks(initial.subtasks || []);
    }
  }, [initial]);

  const addTag = () => {
    const t = tagInput.trim().toLowerCase();
    if (t && !tags.includes(t)) setTags([...tags, t]);
    setTagInput("");
  };

  const removeTag = (tag) => setTags(tags.filter((t) => t !== tag));

  const addSubtask = () => {
    const t = subtaskInput.trim();
    if (t) setSubtasks([...subtasks, { id: Date.now().toString(), title: t, completed: false }]);
    setSubtaskInput("");
  };

  const removeSubtask = (id) => setSubtasks(subtasks.filter((s) => s.id !== id));

  const toggleSubtask = (id) =>
    setSubtasks(subtasks.map((s) => (s.id === id ? { ...s, completed: !s.completed } : s)));

  const handleSubmit = () => {
    if (!title.trim()) { setError("Title is required."); return; }
    onSave({
      title: title.trim(),
      description: description.trim(),
      priority,
      dueDate: dueDate || null,
      tags,
      subtasks,
    });
  };

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{initial ? "Edit Task" : "New Task"}</h2>
          <button className="modal-close" onClick={onClose}>✕</button>
        </div>

        <div className="modal-body">
          {error && <div className="field-error">{error}</div>}

          <label>
            Title <span className="required">*</span>
            <input
              type="text"
              value={title}
              onChange={(e) => { setTitle(e.target.value); setError(""); }}
              placeholder="What needs to be done?"
              autoFocus
            />
          </label>

          <label>
            Description
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Add details…"
              rows={3}
            />
          </label>

          <div className="row-fields">
            <label>
              Priority
              <select value={priority} onChange={(e) => setPriority(e.target.value)}>
                <option value="low">🟢 Low</option>
                <option value="medium">🟡 Medium</option>
                <option value="high">🔴 High</option>
              </select>
            </label>

            <label>
              Due Date
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
              />
            </label>
          </div>

          {/* Tags */}
          <label>Tags</label>
          <div className="tag-input-row">
            <input
              type="text"
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              placeholder="Add a tag…"
              onKeyDown={(e) => e.key === "Enter" && addTag()}
            />
            <button className="btn-secondary" onClick={addTag}>Add</button>
          </div>
          {tags.length > 0 && (
            <div className="tags-list">
              {tags.map((t) => (
                <span key={t} className="tag-chip">
                  #{t} <button onClick={() => removeTag(t)}>✕</button>
                </span>
              ))}
            </div>
          )}

          {/* Subtasks */}
          <label>Subtasks</label>
          <div className="tag-input-row">
            <input
              type="text"
              value={subtaskInput}
              onChange={(e) => setSubtaskInput(e.target.value)}
              placeholder="Add a subtask…"
              onKeyDown={(e) => e.key === "Enter" && addSubtask()}
            />
            <button className="btn-secondary" onClick={addSubtask}>Add</button>
          </div>
          {subtasks.length > 0 && (
            <ul className="subtask-list">
              {subtasks.map((s) => (
                <li key={s.id}>
                  <button
                    className={`sub-check ${s.completed ? "checked" : ""}`}
                    onClick={() => toggleSubtask(s.id)}
                  >
                    {s.completed ? "✓" : ""}
                  </button>
                  <span className={s.completed ? "sub-done" : ""}>{s.title}</span>
                  <button className="sub-remove" onClick={() => removeSubtask(s.id)}>✕</button>
                </li>
              ))}
            </ul>
          )}
        </div>

        <div className="modal-footer">
          <button className="btn-ghost" onClick={onClose}>Cancel</button>
          <button className="btn-primary" onClick={handleSubmit}>
            {initial ? "Save changes" : "Create task"}
          </button>
        </div>
      </div>
    </div>
  );
}
