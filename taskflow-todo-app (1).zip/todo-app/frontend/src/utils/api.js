const BASE_URL = process.env.REACT_APP_API_URL || "http://localhost:3001/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json", ...options.headers },
    ...options,
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

export const api = {
  // Get all todos with optional filters
  getTodos: (params = {}) => {
    const qs = new URLSearchParams(
      Object.entries(params).filter(([, v]) => v !== undefined && v !== "")
    ).toString();
    return request(`/todos${qs ? "?" + qs : ""}`);
  },

  // Get a single todo
  getTodo: (id) => request(`/todos/${id}`),

  // Create a todo
  createTodo: (todo) =>
    request("/todos", { method: "POST", body: JSON.stringify(todo) }),

  // Full update
  updateTodo: (id, todo) =>
    request(`/todos/${id}`, { method: "PUT", body: JSON.stringify(todo) }),

  // Partial update (toggle, patch fields)
  patchTodo: (id, changes) =>
    request(`/todos/${id}`, { method: "PATCH", body: JSON.stringify(changes) }),

  // Delete a single todo
  deleteTodo: (id) => request(`/todos/${id}`, { method: "DELETE" }),

  // Clear all completed todos
  clearCompleted: () =>
    request("/todos?clearCompleted=true", { method: "DELETE" }),
};
