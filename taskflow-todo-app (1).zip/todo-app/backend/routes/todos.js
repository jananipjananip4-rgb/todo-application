const express = require("express");
const { v4: uuidv4 } = require("uuid");
const { readTodos, writeTodos } = require("./store");

const router = express.Router();

// Valid priority values
const VALID_PRIORITIES = ["low", "medium", "high"];

// GET /api/todos — list all todos with optional filter/sort/search
router.get("/", (req, res) => {
  let todos = readTodos();

  const { status, priority, search, sortBy, sortOrder } = req.query;

  // Filter by status: "active" | "completed"
  if (status === "active") {
    todos = todos.filter((t) => !t.completed);
  } else if (status === "completed") {
    todos = todos.filter((t) => t.completed);
  }

  // Filter by priority
  if (priority && VALID_PRIORITIES.includes(priority)) {
    todos = todos.filter((t) => t.priority === priority);
  }

  // Search by title or description
  if (search) {
    const q = search.toLowerCase();
    todos = todos.filter(
      (t) =>
        t.title.toLowerCase().includes(q) ||
        (t.description && t.description.toLowerCase().includes(q))
    );
  }

  // Sort
  const order = sortOrder === "asc" ? 1 : -1;
  if (sortBy === "title") {
    todos.sort((a, b) => order * a.title.localeCompare(b.title));
  } else if (sortBy === "priority") {
    const rankMap = { high: 3, medium: 2, low: 1 };
    todos.sort((a, b) => order * (rankMap[a.priority] - rankMap[b.priority]));
  } else if (sortBy === "dueDate") {
    todos.sort((a, b) => {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return order * (new Date(a.dueDate) - new Date(b.dueDate));
    });
  } else {
    // Default: sort by createdAt descending
    todos.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
  }

  res.json(todos);
});

// GET /api/todos/:id — get a single todo
router.get("/:id", (req, res) => {
  const todos = readTodos();
  const todo = todos.find((t) => t.id === req.params.id);
  if (!todo) return res.status(404).json({ error: "Todo not found" });
  res.json(todo);
});

// POST /api/todos — create a new todo
router.post("/", (req, res) => {
  const { title, description, priority, dueDate, tags, subtasks } = req.body;

  if (!title || typeof title !== "string" || title.trim() === "") {
    return res.status(400).json({ error: "Title is required" });
  }

  if (priority && !VALID_PRIORITIES.includes(priority)) {
    return res.status(400).json({ error: "Priority must be low, medium, or high" });
  }

  const now = new Date().toISOString();
  const newTodo = {
    id: uuidv4(),
    title: title.trim(),
    description: description ? description.trim() : "",
    completed: false,
    priority: priority || "medium",
    dueDate: dueDate || null,
    tags: Array.isArray(tags) ? tags : [],
    subtasks: Array.isArray(subtasks)
      ? subtasks.map((s) => ({ id: uuidv4(), title: s.title || s, completed: false }))
      : [],
    createdAt: now,
    updatedAt: now,
    completedAt: null,
  };

  const todos = readTodos();
  todos.push(newTodo);
  writeTodos(todos);

  res.status(201).json(newTodo);
});

// PUT /api/todos/:id — full update of a todo
router.put("/:id", (req, res) => {
  const todos = readTodos();
  const idx = todos.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Todo not found" });

  const { title, description, priority, dueDate, tags, subtasks } = req.body;

  if (title !== undefined && (typeof title !== "string" || title.trim() === "")) {
    return res.status(400).json({ error: "Title cannot be empty" });
  }
  if (priority !== undefined && !VALID_PRIORITIES.includes(priority)) {
    return res.status(400).json({ error: "Priority must be low, medium, or high" });
  }

  const existing = todos[idx];
  const updated = {
    ...existing,
    title: title !== undefined ? title.trim() : existing.title,
    description: description !== undefined ? description.trim() : existing.description,
    priority: priority !== undefined ? priority : existing.priority,
    dueDate: dueDate !== undefined ? dueDate : existing.dueDate,
    tags: tags !== undefined ? (Array.isArray(tags) ? tags : existing.tags) : existing.tags,
    subtasks:
      subtasks !== undefined
        ? Array.isArray(subtasks)
          ? subtasks.map((s) =>
              typeof s === "string"
                ? { id: uuidv4(), title: s, completed: false }
                : { id: s.id || uuidv4(), title: s.title, completed: s.completed || false }
            )
          : existing.subtasks
        : existing.subtasks,
    updatedAt: new Date().toISOString(),
  };

  todos[idx] = updated;
  writeTodos(todos);
  res.json(updated);
});

// PATCH /api/todos/:id — partial update (toggle complete, change field)
router.patch("/:id", (req, res) => {
  const todos = readTodos();
  const idx = todos.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Todo not found" });

  const existing = todos[idx];
  const updates = { ...req.body, updatedAt: new Date().toISOString() };

  // Handle completed toggle with timestamp
  if ("completed" in updates) {
    updates.completedAt = updates.completed ? new Date().toISOString() : null;
  }

  // Handle subtask completion
  if ("subtasks" in updates && Array.isArray(updates.subtasks)) {
    updates.subtasks = updates.subtasks.map((s) => ({
      id: s.id || uuidv4(),
      title: s.title,
      completed: s.completed || false,
    }));
  }

  todos[idx] = { ...existing, ...updates };
  writeTodos(todos);
  res.json(todos[idx]);
});

// DELETE /api/todos/:id — delete a todo
router.delete("/:id", (req, res) => {
  const todos = readTodos();
  const idx = todos.findIndex((t) => t.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: "Todo not found" });

  todos.splice(idx, 1);
  writeTodos(todos);
  res.json({ message: "Todo deleted successfully" });
});

// DELETE /api/todos — bulk delete completed todos
router.delete("/", (req, res) => {
  if (req.query.clearCompleted !== "true") {
    return res.status(400).json({ error: "Use ?clearCompleted=true to bulk delete" });
  }
  let todos = readTodos();
  const before = todos.length;
  todos = todos.filter((t) => !t.completed);
  writeTodos(todos);
  res.json({ message: `Deleted ${before - todos.length} completed todos` });
});

module.exports = router;
