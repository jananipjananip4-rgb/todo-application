import React, { useEffect, useState } from "react";
import { useSearchParams, Link, useNavigate } from "react-router-dom";
import axios from "axios";

const API = "http://localhost:5000";

function TodoDetail() {
  const [searchParams] = useSearchParams();
  const id = searchParams.get("id");
  const navigate = useNavigate();

  const [todo, setTodo] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [editing, setEditing] = useState(false);
  const [form, setForm] = useState({});

  useEffect(() => {
    if (!id) {
      setError("No todo ID provided.");
      setLoading(false);
      return;
    }
    fetchTodo();
  }, [id]);

  async function fetchTodo() {
    try {
      const res = await axios.get(`${API}/todos/${id}`);
      setTodo(res.data);
      setForm(res.data);
    } catch (err) {
      setError("Todo not found.");
    } finally {
      setLoading(false);
    }
  }

  async function saveEdit() {
    await axios.put(`${API}/todos/${id}`, form);
    setTodo(form);
    setEditing(false);
  }

  async function toggleComplete() {
    const updated = { ...todo, completed: !todo.completed };
    await axios.put(`${API}/todos/${id}`, updated);
    setTodo(updated);
    setForm(updated);
  }

  async function deleteTodo() {
    if (!window.confirm("Delete this todo?")) return;
    await axios.delete(`${API}/todos/${id}`);
    navigate("/");
  }

  if (loading) return <div className="loading">Loading...</div>;
  if (error) return <div className="error">{error} <br /><Link to="/">← Back to list</Link></div>;

  return (
    <div className="container">
      <Link to="/" className="back-link">← Back to all todos</Link>

      <div className="detail-card">
        {editing ? (
          <>
            <div className="detail-row">
              <label>Title</label>
              <input
                className="edit-input"
                value={form.title}
                onChange={(e) => setForm({ ...form, title: e.target.value })}
              />
            </div>
            <div className="detail-row">
              <label>Description</label>
              <textarea
                className="edit-input"
                rows={4}
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
              />
            </div>
            <div className="detail-row">
              <label>Priority</label>
              <select
                className="edit-input"
                value={form.priority}
                onChange={(e) => setForm({ ...form, priority: e.target.value })}
              >
                <option value="high">High</option>
                <option value="medium">Medium</option>
                <option value="low">Low</option>
              </select>
            </div>
            <div className="detail-row">
              <label>Due Date</label>
              <input
                className="edit-input"
                type="date"
                value={form.dueDate || ""}
                onChange={(e) => setForm({ ...form, dueDate: e.target.value })}
              />
            </div>
            <div className="detail-actions">
              <button className="btn btn-primary" onClick={saveEdit}>Save</button>
              <button className="btn btn-secondary" onClick={() => setEditing(false)}>Cancel</button>
            </div>
          </>
        ) : (
          <>
            <h1>{todo.title}</h1>

            <div className="detail-row">
              <label>Status</label>
              <p>{todo.completed ? "✅ Completed" : "⏳ Pending"}</p>
            </div>

            <div className="detail-row">
              <label>Priority</label>
              <p><span className={`priority-badge priority-${todo.priority}`}>{todo.priority}</span></p>
            </div>

            <div className="detail-row">
              <label>Description</label>
              <p>{todo.description || <em style={{ color: "#aaa" }}>No description</em>}</p>
            </div>

            <div className="detail-row">
              <label>Due Date</label>
              <p>{todo.dueDate ? `📅 ${todo.dueDate}` : "No due date"}</p>
            </div>

            <div className="detail-row">
              <label>Created</label>
              <p>{new Date(todo.createdAt).toLocaleString()}</p>
            </div>

            <div className="detail-row">
              <label>Last Updated</label>
              <p>{new Date(todo.updatedAt).toLocaleString()}</p>
            </div>

            <div className="detail-row">
              <label>ID</label>
              <p style={{ fontSize: "0.8rem", color: "#aaa" }}>{todo.id}</p>
            </div>

            <div className="detail-actions">
              <button className="btn btn-primary" onClick={() => setEditing(true)}>✏️ Edit</button>
              <button className="btn btn-secondary" onClick={toggleComplete}>
                {todo.completed ? "↩️ Mark Pending" : "✅ Mark Done"}
              </button>
              <button className="btn btn-danger" onClick={deleteTodo}>🗑️ Delete</button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

export default TodoDetail;
