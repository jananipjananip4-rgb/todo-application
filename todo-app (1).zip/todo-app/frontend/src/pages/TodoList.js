import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import axios from "axios";

const API = "http://localhost:5000";

function TodoList() {
  const [todos, setTodos] = useState([]);
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [priority, setPriority] = useState("medium");
  const [dueDate, setDueDate] = useState("");
  const [filter, setFilter] = useState("all");
  const [search, setSearch] = useState("");
  const [sort, setSort] = useState("newest");
  const navigate = useNavigate();

  useEffect(() => {
    fetchTodos();
  }, []);

  async function fetchTodos() {
    const res = await axios.get(`${API}/todos`);
    setTodos(res.data);
  }

  async function addTodo(e) {
    e.preventDefault();
    if (!title.trim()) return;
    await axios.post(`${API}/todos`, { title, description, priority, dueDate });
    setTitle("");
    setDescription("");
    setPriority("medium");
    setDueDate("");
    fetchTodos();
  }

  async function toggleComplete(todo) {
    await axios.put(`${API}/todos/${todo.id}`, { ...todo, completed: !todo.completed });
    fetchTodos();
  }

  async function deleteTodo(id) {
    if (!window.confirm("Delete this todo?")) return;
    await axios.delete(`${API}/todos/${id}`);
    fetchTodos();
  }

  // filter
  let visible = todos.filter((t) => {
    if (filter === "active") return !t.completed;
    if (filter === "completed") return t.completed;
    return true;
  });

  // search
  if (search.trim()) {
    visible = visible.filter((t) =>
      t.title.toLowerCase().includes(search.toLowerCase())
    );
  }

  // sort
  visible = [...visible].sort((a, b) => {
    if (sort === "newest") return new Date(b.createdAt) - new Date(a.createdAt);
    if (sort === "oldest") return new Date(a.createdAt) - new Date(b.createdAt);
    if (sort === "priority") {
      const order = { high: 0, medium: 1, low: 2 };
      return order[a.priority] - order[b.priority];
    }
    if (sort === "due") {
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate) - new Date(b.dueDate);
    }
    return 0;
  });

  const total = todos.length;
  const done = todos.filter((t) => t.completed).length;
  const pending = total - done;

  return (
    <div className="container">
      {/* Stats */}
      <div className="stats">
        <div className="stat-box"><div className="num">{total}</div><div className="label">Total</div></div>
        <div className="stat-box"><div className="num">{pending}</div><div className="label">Pending</div></div>
        <div className="stat-box"><div className="num">{done}</div><div className="label">Done</div></div>
      </div>

      {/* Add form */}
      <div className="add-form">
        <h2>Add a new todo</h2>
        <form onSubmit={addTodo}>
          <div className="form-row">
            <input
              type="text"
              placeholder="What needs to be done?"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              required
            />
          </div>
          <div className="form-row">
            <textarea
              placeholder="Description (optional)"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
            />
          </div>
          <div className="form-row">
            <select value={priority} onChange={(e) => setPriority(e.target.value)}>
              <option value="high">🔴 High priority</option>
              <option value="medium">🟡 Medium priority</option>
              <option value="low">🟢 Low priority</option>
            </select>
            <input
              type="date"
              value={dueDate}
              onChange={(e) => setDueDate(e.target.value)}
            />
            <button type="submit" className="btn btn-primary">Add</button>
          </div>
        </form>
      </div>

      {/* Search & Sort */}
      <input
        className="search-bar"
        type="text"
        placeholder="Search todos..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* Filters */}
      <div className="filters">
        {["all", "active", "completed"].map((f) => (
          <button
            key={f}
            className={`filter-btn ${filter === f ? "active" : ""}`}
            onClick={() => setFilter(f)}
          >
            {f.charAt(0).toUpperCase() + f.slice(1)}
          </button>
        ))}
        <select className="sort-select" value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="newest">Newest first</option>
          <option value="oldest">Oldest first</option>
          <option value="priority">By priority</option>
          <option value="due">By due date</option>
        </select>
      </div>

      {/* List */}
      {visible.length === 0 ? (
        <div className="empty">
          <p>No todos here!</p>
          <span>Add one above ☝️</span>
        </div>
      ) : (
        visible.map((todo) => (
          <div key={todo.id} className={`todo-card ${todo.completed ? "completed" : ""}`}>
            <input
              type="checkbox"
              checked={todo.completed}
              onChange={() => toggleComplete(todo)}
            />
            <div className="todo-info" onClick={() => navigate(`/todo?id=${todo.id}`)}>
              <div className="todo-title">{todo.title}</div>
              <div className="todo-meta">
                <span className={`priority-badge priority-${todo.priority}`}>{todo.priority}</span>
                {todo.dueDate && <span>📅 {todo.dueDate}</span>}
                <span>Created {new Date(todo.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
            <div className="todo-actions">
              <button className="icon-btn" title="View" onClick={() => navigate(`/todo?id=${todo.id}`)}>👁️</button>
              <button className="icon-btn" title="Delete" onClick={() => deleteTodo(todo.id)}>🗑️</button>
            </div>
          </div>
        ))
      )}
    </div>
  );
}

export default TodoList;
