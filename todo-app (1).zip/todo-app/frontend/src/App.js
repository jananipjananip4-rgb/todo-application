import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import TodoList from "./pages/TodoList";
import TodoDetail from "./pages/TodoDetail";

function App() {
  return (
    <Router>
      <nav className="navbar">
        <Link to="/" className="nav-brand">📝 Todo App</Link>
      </nav>
      <Routes>
        <Route path="/" element={<TodoList />} />
        <Route path="/todo" element={<TodoDetail />} />
      </Routes>
    </Router>
  );
}

export default App;
