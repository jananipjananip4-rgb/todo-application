const express = require("express");
const cors = require("cors");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
const path = require("path");

const app = express();
const PORT = 5000;
const DATA_FILE = path.join(__dirname, "todos.json");

app.use(cors());
app.use(express.json());

// Helper: read todos from file
function readTodos() {
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, JSON.stringify([]));
  }
  const data = fs.readFileSync(DATA_FILE, "utf-8");
  return JSON.parse(data);
}

// Helper: write todos to file
function writeTodos(todos) {
  fs.writeFileSync(DATA_FILE, JSON.stringify(todos, null, 2));
}

// GET /todos - get all todos
app.get("/todos", (req, res) => {
  const todos = readTodos();
  res.json(todos);
});

// GET /todos/:id - get single todo
app.get("/todos/:id", (req, res) => {
  const todos = readTodos();
  const todo = todos.find((t) => t.id === req.params.id);
  if (!todo) return res.status(404).json({ error: "Todo not found" });
  res.json(todo);
});

// POST /todos - create a new todo
app.post("/todos", (req, res) => {
  const { title, description, priority, dueDate } = req.body;

  if (!title || title.trim() === "") {
    return res.status(400).json({ error: "Title is required" });
  }

  const newTodo = {
    id: uuidv4(),
    title: title.trim(),
    description: description || "",
    priority: priority || "medium",
    dueDate: dueDate || null,
    completed: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };

  const todos = readTodos();
  todos.push(newTodo);
  writeTodos(todos);

  res.status(201).json(newTodo);
});

// PUT /todos/:id - update a todo
app.put("/todos/:id", (req, res) => {
  const todos = readTodos();
  const index = todos.findIndex((t) => t.id === req.params.id);

  if (index === -1) return res.status(404).json({ error: "Todo not found" });

  const updated = {
    ...todos[index],
    ...req.body,
    id: todos[index].id,
    createdAt: todos[index].createdAt,
    updatedAt: new Date().toISOString(),
  };

  todos[index] = updated;
  writeTodos(todos);

  res.json(updated);
});

// DELETE /todos/:id - delete a todo
app.delete("/todos/:id", (req, res) => {
  const todos = readTodos();
  const filtered = todos.filter((t) => t.id !== req.params.id);

  if (filtered.length === todos.length) {
    return res.status(404).json({ error: "Todo not found" });
  }

  writeTodos(filtered);
  res.json({ message: "Todo deleted" });
});

app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});
