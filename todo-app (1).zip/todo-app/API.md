# API Reference

Base URL: `http://localhost:5000`

All request and response bodies are JSON.

---

## Todo Object

```json
{
  "id": "uuid-string",
  "title": "Buy groceries",
  "description": "Milk, eggs, bread",
  "priority": "medium",
  "dueDate": "2024-12-31",
  "completed": false,
  "createdAt": "2024-01-01T10:00:00.000Z",
  "updatedAt": "2024-01-01T10:00:00.000Z"
}
```

| Field | Type | Notes |
|---|---|---|
| `id` | string | UUID, auto-generated |
| `title` | string | Required |
| `description` | string | Optional, defaults to `""` |
| `priority` | string | `"high"`, `"medium"`, or `"low"` |
| `dueDate` | string | ISO date `YYYY-MM-DD`, or `null` |
| `completed` | boolean | Defaults to `false` |
| `createdAt` | string | ISO timestamp, auto-set |
| `updatedAt` | string | ISO timestamp, auto-updated |

---

## Endpoints

### GET /todos
Returns all todos.

**Response:** `200 OK` — array of todo objects

---

### GET /todos/:id
Returns a single todo by ID.

**Response:**
- `200 OK` — todo object
- `404 Not Found` — `{ "error": "Todo not found" }`

---

### POST /todos
Creates a new todo.

**Request body:**
```json
{
  "title": "Buy groceries",
  "description": "Milk, eggs",
  "priority": "high",
  "dueDate": "2024-12-31"
}
```

Only `title` is required.

**Response:**
- `201 Created` — the new todo object
- `400 Bad Request` — `{ "error": "Title is required" }`

---

### PUT /todos/:id
Updates an existing todo. Send the full todo object with updated fields.

**Request body:** (any fields you want to update)
```json
{
  "title": "Updated title",
  "completed": true
}
```

**Response:**
- `200 OK` — the updated todo object
- `404 Not Found` — `{ "error": "Todo not found" }`

---

### DELETE /todos/:id
Deletes a todo by ID.

**Response:**
- `200 OK` — `{ "message": "Todo deleted" }`
- `404 Not Found` — `{ "error": "Todo not found" }`
