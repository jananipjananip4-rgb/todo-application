# Todo App

A full-stack todo application with a React frontend and Node.js/Express backend.

## Tech Stack

- **Frontend:** React, React Router v6, Axios
- **Backend:** Node.js, Express.js
- **Storage:** JSON file (`backend/todos.json`) — auto-created on first run

---

## Multi-Page Architecture

This app has **two separate pages** with different URLs. It is not a single-page application (SPA) — each page is its own route and renders completely independently:

| Page | URL | Description |
|---|---|---|
| Todo List | `http://localhost:3000/` | Shows all todos, add/delete/filter/search |
| Todo Detail | `http://localhost:3000/todo?id=<todoId>` | Shows a single todo by its ID |

To navigate to the detail page, click any todo card or the 👁️ icon on the list page. The URL will change to `/todo?id=...` and the detail page loads. Use the **← Back to all todos** link to return.

---

## Data Storage

All todos are saved to a file: `backend/todos.json`

This file is created automatically when the backend starts for the first time. Every time you add, edit, complete, or delete a todo, the file is updated immediately. Data persists across server restarts.

Example of what the file looks like:

```json
[
  {
    "id": "a1b2c3d4-...",
    "title": "Buy groceries",
    "description": "Milk, eggs, bread",
    "priority": "high",
    "dueDate": "2024-12-31",
    "completed": false,
    "createdAt": "2024-01-01T10:00:00.000Z",
    "updatedAt": "2024-01-01T10:00:00.000Z"
  }
]
```

The file is listed in `.gitignore` so it is not committed to the repository (it is runtime data, not source code).

---

## Getting Started

### 1. Run the Backend

```bash
cd backend
npm install
node server.js
```

Backend runs on `http://localhost:5000`. The `todos.json` file will be created automatically in the `backend/` folder.

### 2. Run the Frontend

```bash
cd frontend
npm install
npm start
```

Frontend runs on `http://localhost:3000`. Make sure the backend is running first.

---

## Features

See [FEATURES.md](./FEATURES.md) for full feature documentation.

## API Reference

See [API.md](./API.md) for all backend endpoints.

---

## Project Structure

```
todo-app/
├── backend/
│   ├── server.js       # Express server — all CRUD API routes
│   ├── todos.json      # Auto-created data file (git-ignored)
│   └── package.json
├── frontend/
│   └── src/
│       ├── App.js              # Sets up the two page routes
│       ├── index.css           # All styles
│       └── pages/
│           ├── TodoList.js     # Page 1: / (todo list)
│           └── TodoDetail.js   # Page 2: /todo?id=... (single todo)
├── FEATURES.md
├── API.md
└── README.md
```
