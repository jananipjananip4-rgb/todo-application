# Features

## How the Two Pages Work

This app has two pages. They are separate routes — not components toggled inside one page.

- **Page 1** lives at `/` and shows the full todo list
- **Page 2** lives at `/todo?id=<todoId>` and shows one specific todo

Clicking a todo on the list page navigates to Page 2 with that todo's ID in the URL. The browser URL bar changes. The back button and browser history work normally.

---

## Page 1: Todo List (`http://localhost:3000/`)

### Add a Todo
- Fill in a **title** (required), optional **description**, **priority** (high / medium / low), and **due date**
- Click **Add** — the todo is sent to the backend, saved to `todos.json`, and appears in the list immediately
- After adding, all form fields reset automatically to their defaults (title cleared, priority back to medium, etc.)
- If the title is empty, the form does not submit

### View Todos
- All todos are shown as cards displaying: title, priority badge (color-coded), due date, and creation date
- Click anywhere on a card, or the 👁️ icon, to open that todo's detail page (Page 2)

### Mark a Todo Complete
- Check the checkbox on any card to toggle it as done
- Completed todos show with strikethrough text and reduced opacity
- Unchecking a completed todo marks it as pending again
- The change is saved to `todos.json` immediately via the backend

### Delete a Todo (from list)
- Click the 🗑️ icon on a card
- A confirmation prompt appears — click OK to delete, Cancel to abort
- Deleted todos are removed from the list and permanently removed from `todos.json`

### Filter Todos
- Three filter buttons appear above the list:
  - **All** — shows every todo regardless of status
  - **Active** — shows only todos that are not completed
  - **Completed** — shows only finished todos
- The active filter button is highlighted in purple

### Search Todos
- Type in the search bar to filter the list by title in real time
- Search is case-insensitive ("MILK" will match "milk")
- Search works together with the active filter — e.g. searching while on "Active" only searches active todos

### Sort Todos
- A dropdown lets you sort the visible todos:
  - **Newest first** — most recently created at the top (default)
  - **Oldest first** — oldest creation date at the top
  - **By priority** — high → medium → low
  - **By due date** — soonest deadline first; todos with no due date go to the bottom
- Sorting works together with the active filter and search

### Stats Bar
- At the top of the page, three counters show: Total todos, Pending todos, Completed todos
- These update live as you add, delete, or complete todos

### Empty State
- If no todos exist (or none match the current filter/search), the page shows "No todos here! Add one above ☝️" instead of a blank list

---

## Page 2: Todo Detail (`http://localhost:3000/todo?id=<todoId>`)

This page loads when you click a todo on the list page. The todo's ID is read from the URL query parameter (`?id=...`) and used to fetch that specific todo from the backend.

### Loading State
- While the todo is being fetched from the backend, the page shows a "Loading..." message

### Error State
- If the ID in the URL does not match any todo (e.g. deleted or invalid URL), the page shows an error message and a link back to the list

### View Details
Displays all stored information for the todo:
- **Title**
- **Status** — ⏳ Pending or ✅ Completed
- **Priority** — color-coded badge (red = high, yellow = medium, green = low)
- **Description** — shows "No description" in grey if empty
- **Due date** — shows "No due date" if none was set
- **Created** — full timestamp of when the todo was first created
- **Last Updated** — full timestamp of the most recent change (auto-updated by backend on every edit)
- **ID** — the unique UUID assigned to this todo

### Edit a Todo
- Click **✏️ Edit** to switch to edit mode — the fields become editable inputs
- You can change: title, description, priority, due date
- Click **Save** to send the update to the backend (saved to `todos.json`) — the page switches back to view mode
- Click **Cancel** to discard changes and go back to view mode without saving
- The `createdAt` and `id` fields cannot be changed — the backend ignores any attempt to overwrite them

### Toggle Status
- Click **✅ Mark Done** to mark the todo as completed
- Click **↩️ Mark Pending** to revert a completed todo back to active
- The button label changes depending on the current status
- The change is saved to `todos.json` immediately

### Delete a Todo (from detail page)
- Click **🗑️ Delete** and confirm the prompt
- The todo is permanently deleted from `todos.json` and you are redirected back to the list page

### Back Navigation
- Click **← Back to all todos** at the top to return to Page 1 without making any changes

---

## Data Storage

All todo data is stored in `backend/todos.json`. This file is read and written by the Express server on every API call. No database setup is required — the file is created automatically when the server first starts.

Each todo stored in the file has these fields:

| Field | Description |
|---|---|
| `id` | Unique UUID, auto-generated on creation, never changes |
| `title` | The todo title |
| `description` | Optional longer description |
| `priority` | `"high"`, `"medium"`, or `"low"` |
| `dueDate` | Date string (`YYYY-MM-DD`) or `null` |
| `completed` | `true` or `false` |
| `createdAt` | ISO timestamp set on creation, never changes |
| `updatedAt` | ISO timestamp, auto-updated on every edit |
